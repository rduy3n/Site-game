# Refonte Fin de Combat, Coup Fatal, Glitcherman & Équilibrage

Mise à niveau complète du ressenti des coups finaux (freeze-frame + filtre + particules + ralenti), refonte des attaques de Glitcherman, rééquilibrage compétitif des 4 combattants et **animations de fin 100 % chorégraphiées image par image** avec les personnages complets articulés (aucune image fixe de personnage).

---

## User Review & Critical Decisions

> [!IMPORTANT]
> **Principe clé confirmé pour les cinématiques de fin** : **Aucune image/portrait statique de personnage** n'est utilisé pour représenter le vainqueur. Chaque combattant est entièrement modélisé en vecteur cel-shaded articulé et exécute une **véritable chorégraphie animée multi-phases à 60 FPS**.

- **Maître Chen** : Dans un **temple samouraï** au crépuscule, fait tournoyer ses baguettes, attrape des nouilles dans son bol de ramen fumant et **les mange réellement en animation** (mouvement de bras, baguettes, tête, bouche et vapeur).
- **Jardin** : Fait jaillir des vignes, arme son bras colossal, **fonce en perspective vers l'avant-plan et pulvérise la caméra** avec bris de vitre, fissures et tremblement d'écran.
- **Daron Brésilien** : Déplie son **transat** sur la plage de Copacabana, s'y allonge, rattrape une **noix de coco avec paille et ombrelle** et **la sirote tranquillement**.
- **Glitcherman** : **Lévite entouré de 4 portails holographiques**, canalise des arcs cyber puis claque des doigts pour **fissurer et disloquer l'écran en pixels glitchés**.
- **Nouvelles capacités de Glitcherman** : **Onde EMP repoussante** (Capacité de Base) + **Frappe Orbitale** (Ultime).
- **Équilibrage** : Rééquilibrage complet des PV, dégâts, cooldowns et jauge d'Ultime des 4 personnages (budget strict de 300 points conservé).

---

## 1. Overview & Core Concept

- **Coup Fatal Cinématique (Freeze-Frame + Ralenti)** : Au coup décisif du match, le jeu fige d'abord la scène pendant ~420 ms (**freeze-frame**) avec un **filtre d'écran impactant** (flash manga haute-contraste, inversion chromatique brève, aberration RVB et vignettage) et une **explosion de particules directionnelles**, avant de libérer un **ralenti K.O.** à `0.16x` avec zoom caméra et bandeau `FINISH`.
- **Glitcherman 2.0** : Remplacement des deux attaques « poing géant » identiques par un vrai kit de contrôle technologique : **Onde EMP** à 360° (repousse + étourdissement) et **Frappe Orbitale** (ciblage satellite + rayon laser céleste).
- **Rééquilibrage des 4 combattants** : Suppression des écarts abusifs (nerf de la cadence/dégâts de Chen et des 75 % PV de l'Ulti de Jardin ; réduction des cooldowns trop lents de Jardin ; ajustement tanking de Daron ; valorisation du contrôle de Glitcherman).
- **Cinématiques de Fin Multi-Phases 60 FPS** : Chaque fin raconte une vraie mini-scène animée en 3 temps (`Préparation -> Action signature -> Boucle de pose victorieuse`) avec le personnage articulé au complet, sans aucune carte-image statique.

---

## 2. User Experience & Visual Design

### A. Séquence de Coup Fatal (Freeze-Frame -> Ralenti K.O.)

```
┌──────────────────┐     ┌──────────────────────────────┐     ┌───────────────────────────┐     ┌──────────────────────┐
│ Coup fatal porté │ ──▶ │ FREEZE-FRAME (~420 ms)       │ ──▶ │ RALENTI K.O. (~1300 ms)   │ ──▶ │ ANIMATION DE FIN     │
│ (dernier round)  │     │ • Action figée à l'impact    │     │ • Temps ralenti (0.16x)   │     │ • Chorégraphie 60fps │
│                  │     │ • Filtre manga N&B/Inversé   │     │ • Chute K.O. & particules │     │   en 3 phases        │
│                  │     │   + aberration RVB & flash   │     │   en suspension           │     │ • Bilan Rang S/A/B/C │
│                  │     │ • Onde de choc + 40 éclats   │     │ • Zoom 1.26x + bannière   │     │ • Boutons d'action   │
└──────────────────┘     └──────────────────────────────┘     └───────────────────────────┘     └──────────────────────┘
```

### B. Chorégraphies Animées de Fin (Zéro Image Statique du Combattant)

```
┌──────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                 CHRONOLOGIE D'UNE ANIMATION DE FIN (60 FPS)                              │
├──────────────────────┬──────────────────────────┬───────────────────────────┬────────────────────────────┤
│ Combattant           │ Phase 1 (0.0s – 0.7s)    │ Phase 2 (0.7s – 1.4s)     │ Phase 3 (1.4s+, boucle)    │
├──────────────────────┼──────────────────────────┼───────────────────────────┼────────────────────────────┤
│ Maître Chen          │ Pose dans la cour du     │ Plonge ses baguettes dans │ Porte les nouilles à sa    │
│ (Temple Samouraï)    │ temple (Torii, pagode,   │ le bol fumant et soulève  │ bouche, mâche avec vapeur  │
│                      │ lanternes, sakura).      │ de longues nouilles d'or. │ et sourire satisfait.      │
├──────────────────────┼──────────────────────────┼───────────────────────────┼────────────────────────────┤
│ Jardin               │ Éruption de lianes ;     │ Fonce vers l'avant-plan   │ Poing collé à l'objectif : │
│ (Bris de Caméra)     │ charge son poing massif  │ en grossissant en 3D pour │ écran fissuré en éclats,   │
│                      │ entouré de ronces d'or.  │ frapper la caméra.        │ débris vitrés & secousse.  │
├──────────────────────┼──────────────────────────┼───────────────────────────┼────────────────────────────┤
│ Daron Brésilien      │ Déplie son transat sur   │ Rattrape au vol une noix  │ Sirote à la paille en      │
│ (Copacabana)         │ la plage de Rio et s'y   │ de coco verte équipée     │ balançant sa jambe sous    │
│                      │ installe avec style.     │ d'une paille & ombrelle.  │ les feux d'artifice.       │
├──────────────────────┼──────────────────────────┼───────────────────────────┼────────────────────────────┤
│ Glitcherman          │ Lévite au centre de 4    │ Tend les mains, charge    │ Claque des doigts : écran  │
│ (Lévitation Cyber)   │ portails cyber rotatifs  │ des arcs EMP cyan/magenta │ fissuré en blocs de pixels │
│                      │ qui s'ouvrent en halo.   │ vers l'avant-plan.        │ qui flottent autour de lui.│
└──────────────────────┴──────────────────────────┴───────────────────────────┴────────────────────────────┘
```

### C. Refonte Glitcherman & Rééquilibrage des 4 Combattants

| Combattant | PV / Défense | Attaque Classique | Capacité de Base | Ultime |
| :--- | :--- | :--- | :--- | :--- |
| **Glitcherman** *(Contrôle Techno)* | `1650 PV` · `10%` | **Frappe Pixel** (`48` dmg, `420 ms`) | **Onde EMP** (`85` dmg, `2.4 s`, onde 360° + gros recul + stun) | **Frappe Orbitale** (`320` dmg, ciblage ennemi + rayon orbital) |
| **Jardin** *(Colosse Sylvestre)* | `1800 PV` · `14%` | **Poing Racinaire** (`64` dmg, `620 ms`) | **Fouet de Ronces** (`105` dmg, `3.1 s`) | **Vignes & Poing Colossal** (`45% PV max`, rééquilibré depuis 75%) |
| **Maître Chen** *(Vitesse Baguettes)* | `1550 PV` · `8%` | **Double Baguettes** (`42` dmg, `340 ms`) | **Tourbillon de Baguettes** (`96` dmg, `2.3 s`) | **Déluge Impérial** (`325` dmg) |
| **Daron Brésilien** *(Tank Carioca)* | `1950 PV` · `18%` | **Torgnole Tropicale** (`54` dmg, `520 ms`) | **Balayette Carioca** (`92` dmg, `2.6 s`) | **Samba Bulldozer** (`315` dmg) |

---

## 3. Key Product Decisions & Trade-Offs

- **Animation vectorielle complète sur Canvas plutôt qu'image/portrait**
  - *Choix* : Construire un moteur d'animation multi-segments dans la cinématique de fin qui dessine tout le corps cel-shaded du combattant (tête, yeux/lunettes/visière, mâchoire, torse, deux bras articulés, mains, accessoires, jambes) piloté par le temps écoulé (`elapsedMs`).
  - *Raison* : Permet au personnage d'exécuter de véritables gestes complexes (soulever les nouilles et manger, frapper la caméra en perspective, siroter la noix de coco, léviter et casser l'écran en pixels) sans aucune image figée.
- **Freeze-frame intégré au flux `KO_SLOWMO`**
  - *Choix* : Enchaîner un timer `koFreezeRemainingMs` (~420 ms) avant le décompte du ralenti `0.16x`, avec génération immédiate d'une rafale de particules fatales et application d'un filtre visuel d'écran.
  - *Raison* : Donne un impact massif dès le coup fatal tout en gardant la compatibilité avec la synchronisation en ligne.
- **Équilibre à budget 300 points et suppression de l'Ulti one-shot**
  - *Choix* : Ramener l'Ultime de Jardin de 75 % à 45 % des PV max tout en rendant son kit de base plus fluide, et tempérer la cadence/dégâts de Maître Chen.
  - *Raison* : Rend tous les duels compétitifs et encourage l'utilisation de combos et de capacités plutôt qu'un spam unique.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

```
┌─────────────────────┐        ┌───────────────────────────────┐        ┌──────────────────────────┐
│   FighterRoster     │ ─────▶ │         CombatEngine          │ ─────▶ │    ArenaWorldState       │
│ • Stats équilibrées │        │ • EMP Pulse (360° + knockback)│        │ • koFreezeRemainingMs    │
│ • EMP + Orbital     │        │ • Orbital Strike (ciblé haut) │        │ • koFreezeTotalMs        │
│ • 300 pts / perso   │        │ • Freeze-Frame -> Ralenti K.O.│        │ • fatalParticles         │
└─────────────────────┘        └───────────────────────────────┘        └──────────────────────────┘
                                                                                     │
                       ┌─────────────────────────────────────────────────────────────┴──────────────────────┐
                       ▼                                                                                    ▼
       ┌──────────────────────────────────┐                                                ┌──────────────────────────────────┐
       │   ArenaCanvas + KoSlowMoOverlay  │                                                │     VictoryCinematicOverlay      │
       │ • Filtre N&B/Contraste + RGB     │                                                │ • Décors + Persos articulés 60fps│
       │ • Particules fatales & éclats    │                                                │ • Bilan Arcade (Rang S/A/B/C)    │
       │ • VFX EMP & Rayon Orbital        │                                                │ • Aucune image statique de perso │
       └──────────────────────────────────┘                                                └──────────────────────────────────┘
```

- **Moteur & Modèles** :
  - Ajout de `MoveEffectType.EMP_PULSE` (hit-check bidirectionnel autour de Glitcherman, fort recul et stun) et `MoveEffectType.ULTI_ORBITAL_STRIKE` (capture de la coordonnée `targetX` de l'adversaire pour ancrer le rayon satellite descendant).
  - Ajout de `FatalParticle` et `koFreezeRemainingMs` dans `ArenaWorldState`. Durant le freeze-frame, `CombatEngine` fige la simulation physique et n'avance que `koFreezeRemainingMs`, puis bascule automatiquement en simulation ralentie.
- **Rendu Arène & Filtre Fatal** :
  - `ArenaCanvas` applique un filtre d'impact (ColorMatrix haute-contraste / inversion éclair sur les 160 premières ms puis teinte cinématique contrastée + franges chromatiques + particules véloces) et dessine les nouveaux VFX de Glitcherman (anneaux EMP électromagnétiques + faisceau laser orbital vertical avec réticule au sol).
- **Cinématiques de Fin & Bilan Arcade** :
  - Remplacement complet du rendu de fond dans `VictoryCinematicOverlay` par 4 scènes animées Canvas dédiées avec décors riches + personnages détaillés multi-articulés exécutant leurs 3 phases d'action, superposés au **Bilan Arcade compact** (Rang `S / A / B / C`, dégâts, combo max, rejouer cinématique, boutons de mode).
